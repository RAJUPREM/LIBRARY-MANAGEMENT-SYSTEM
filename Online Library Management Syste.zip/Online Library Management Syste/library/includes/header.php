
<!DOCTYPE html> 
<html>
<head>
<title>Login</title>  
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="lib.css">
  <link rel="stylesheet" type="text/css" href="lib1.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body> 
  <div class="container-fluid">
 <div class="row">
 <div class="navbar">
 <ul class="nav navbar-nav navbar-left">
<li><a href="index1.php"><img height="140px" width="140px" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAREhUSEBIVFRUVFhUWGBgVGBYVFxgXFRUXFxUYGhYYHykgGholHRcWITEhJzUrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy8mHyUtLS0uLS0tLy4uMC4tLS0uLy0tLi0tLS0tLSstLS0rLTUrLS0tLS0tLy0rLy0tLS0uLf/AABEIAOUA3AMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQQCBQYDB//EAEQQAAEDAgQCBwQHBgUDBQAAAAEAAgMEEQUSITFBUQYTIjJhcYEHQpGhFBUjM2KSsVJywcLR4VOCorLwk9LxFhckNEP/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAgMEBQEG/8QAMxEBAAIBAQQHBwUBAAMAAAAAAAECAxEEEjFBBRMhUWGh8BRxgZGx0eEiMjNCwfE0UqL/2gAMAwEAAhEDEQA/APt+yDJAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBBKCMqDJBjsgyQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEEEoACCUBAQY7IMkBAQEBAQEBAQEBAQEBAQEBAQEBAQQSgAIJQEBAQEGOyDJAQEBAQEBAQEBAQEBAQEBAQEBBBKAAglAQEBAQEBBjsgyQEBAQEBAQEBAQEBAQEBAQEEEoACCUBAQEBAQEBAQY7IMkBAQEBAQEBBBKDFkgOxv5f1Xsxo8iYngzXj0QEBAQQSgAIJQEBAQEBAQEBAQEEbIJQEBAQEBBqcYxtkBbG0dZM+wZG3c3NgSfdb4/3WjBs1skTaeyscZ9cZY9p2yuGYpEa2nhH37oe9NRuPandndvYaRt8A3j5uufLZQteOFI0jz9e5bTFae3JOs+Xy+/kvAKpelAQEBBBKAAglAQEBAQEBAQEBAQEBBCCUBAQEFPF65sEL5Xe429uZ2aPU2Ctw4py3ikc1O0Zow4rZJ5ODGamq6aoqb3laXvdyc8ObbwDWuZp/ZdjszYMmPFynSI8I0+s6vne3Z9qxZs39o1mfGdY/+Y0fRY3ggEEEEXBGoI81wtNOyX08TExrDNHogICCCUABBKAgICAgICAgICAgIMXi4I8EeS1VPjDWydRUEMk90nRkg4OaefNu4PNaJwTNesx9sece/wC7LXaorfq8vZbl3T4x9v8ArbXWdrNkEoCAg5vp/f6IeWeO/lf+tlv6N/n+EuX0xr7LPvjX5tpX0ENVEGyNzNcA4EbjTQtPBZseW+G+tZ0n1xbM2DFtOPdvGsT2/mHNNwTEKM3o5RLH/hvt+h09QQuh7Ts20fzV0nvj193KjY9r2X/x7b1e6fX00WKfpnkdkrIXwu52Jb523t5XVd+jptG9htFo9euSynS8Und2ik1ny9fN09LVMlaHxuDmnYtNwufalqTpaNJdbHkrkrvUnWHsopoJQAEEoNe3Eg+Tqou0W/eOHdZybfi88uAuTwBtnFNab1uzXh4/hnjPFr7lO3TjPKPD3z3fNsFU0CAgICAgICAgICAgoYxhMVTGY5RpwI7zTzBV2DPfDbeqz7Ts2PaKbl4/DhJ63EMOkERfnYe5nGZjh4Em7T4X0+C7VcWzbXXf00nnpxh85bNtmw5OrmdY5a8J/wB+Grc0vTpgOSphfE7jbUerTZw+ax36LtMb2K0THr4N+PpqsTu5qTWfXx+rpMPxSCcXhka/wG482nULBkw5MU6XjR1cO04s0a47RK6ql4gp4vQieF8R99tr8ju0+hAVuHLOLJF45KdowxmxWxzzc90JxUgGjn7MsVw2/FoO3mP0tyW3pDBHZnp+231/P1czoraZ7dmydlq/T8fR1q5rsquIUMUzCyVoc08+HiDwPip48lsdt6s6SqzYaZa7l41hxPQQSR1c8LSTG0Pvyu14a13mdf8AgXY6R3b4KZJ4zp5x2vn+iN/HtN8UT+mNfnE6RPr/AB35K4j6V4VNZFEM0r2sHNxA+F1OlLXnSsaq8mWmONbzER4ucxDp1TM0iDpT4DK34nX4Ardi6My27baR5+vm5ebprBTspraflHr4NVSV1dibywO6mEd8s00/Zzbud4aDmtOTFs+x11mN63LVjxZtq6QtNYndpz0+mvf5O1w3D44IxHG2zR8SeJJ4lcnLltltNrcXew4KYaRSkdkLarXCAgICAgICAgICAgIKGM4XHUxmOQaHUHi13AhXYM1sN9+rPtOzU2jHNL/8nvafAqYSRupaxjXvgIaC4XzRuv1bmnfgRpy5rRnvuXjNhnSLfXnDHsmPfpODaI1mvfzieE/4p4j0GbfPSSGNw1AJJF/Bw7Tfmr8XSdtN3LGseuXBnz9C113sFt2fXPjHmr03SOso3CKtjLm7B+l/R2z/AJFTvsmDaI38E6T3eu2FVNv2nZbbm011jv8Azwn6uxw+vinYHxODgeW4PIjgfBcrJitjtu3jSXcw5qZq71J1haIUFrjenWGOblrIOy+MjMRy2a702PgfBdXo7NE64L9sTw+zh9LbPaum04uy0cf8n4fRvejmLfSoGybHuuA2DhvbwNwfVYtqwThyTTly9zo7FtUbRhi/PhPvTidc+5ipxmlPE9yMH3nn5hu5XmLHWf15OyvnPhH3e581v48Ua28o8Z/yOMqlDT0+HQkyP1cbve7vPd4DfnYf3KsyXy7Xk/THujuhThx4dgxTNp48ZnjM+uDRVHSirqnGOhiIGxeQC7zueyz5rdXYcOCN7Pb4eu2XOv0ltG023Nmr2d/rsjze1H0Ic89ZWTOe47hpJ9C938FDJ0nFY3cNdI9ck8XQ03nf2i+s+H3RieEsdK2ipGCNoAfPIBd2UnstLjqSbXtxuOAKYtotFJz5p1nhWPHv0M+y1tkjZcEaRxtPhyjV11BRRwsbHG2zWjT+JPMnmuZkyWyWm1p7XZw4qYqRSkaRCyoLRAQEBAQEBAQEBAQVKwzgXiEbvwvzNv8A5hf9FZTc/vr8PX+qcnWxGtNJ8J7PP8OdqemL4HZamkfGeBDg4HyNgD6Fb6dHVyRriyRPwcvJ0tbDbdzYpj46/Lgs0vTWif3nPZ++0/q24Vd+jc9eUT7p+63H0zstuMzHvj7atrS1MErhJFIx5ALey4E2JBsQPEf8ust6ZKRu2iY97djyYss71LRPuleVS95VdKyVpZI0OadwRcKVL2pO9WdJQyY65K7t41hxGJYVPhz/AKRSEuj99p1s3k7m38W4+a6+HPj2uvVZf3cp9fRwM+y5dhv12Dtrzjw8fDx4w67BcVjqYhJGfBwO7XcQVzM+C2G+5Z2tl2mm0Y4vT/j3xCIPika7ZzHA+RaQoY7TW8THfCzLWLY7VnhMS5v2cwkUznH35CR5ANbf4g/Bb+lbROaI7ocroOk12eZnnP4bLHMXhoor2u918reLncSTy5lZ9m2e+0X05Rxnua9r2vHsmPXnPCO+fXFzuGYDPXP+kVziGnVrNiR5e635nw3O/LtePZo6rBHbzn1xnyczZ9hy7Xbrtpns5R64R5u2paWONoZG0NaODRYLkXva871p1l3seOuOu7SNIet1FNpjiNHTF5kmZme4vdrmeTsBlbc2AsB5LVGHPm03azpHZHcwztGz7PrvXjWZ1nv+Ud0djX1PTukb3RI/yaAP9RB+Svp0XmnjpHrwZb9N7PX9us/D7vfDsdqajWKlys/blflBHgA259NPFV5tmxYey19Z7oj8rsG25s/bTHpXvmdP8dBEHW7RBPhoPmsc6cnRjXTtZrx6ICAgICAgICBdBCDxq6SOVpZIwOaeBF//AAfFSpe1J3qzpKGTHTJXdvGsOZHRilhLhKwOicbtcbh7CfcLm2JbyPoeC3W6Qy2iLVnSY490+P3cynRWCszW1dazw748NY4x3MaroHCTmhkfG7hezgP0PzU6dKZOF4iY+SrJ0Ji11x2ms/P7T5vDJi9HsRURjhq429bP/VWa7Fn4/pn5fj6K93pHZeE79fnP3+rYYX0yp5OzNeF43D+7+bh62WfP0fkxxvV/VHg17N0riyzu3/Tbun7/AHb+aZgbmcRlPPY3WB0+LjqmA4ZUiWO/0aU5XgbMP9tx4XC69Le2YZpb99eHj6+zg5KT0ftEZK/x27J8PX3h0fSGryU0hbq5zcjLcXSdltvzX9Fg2Wm9liJ5ds/DtdTbMu5gtNeM9ke+eyGcTY6OmAJs2Jmp5kbnzJ+ZUbTbaMvZxtPr5JVimy4I14Vj183N4Bhr62U1tSOzf7Jh2sNv8o+ZufPobTmjZ6ez4uPOXK2PZ7bXl9qzR2f1j1617XVVmIww/evDdL68h/zZcumO150rGsu1ky0xV3rzpDmqnpjJK4x0MDpD+04G3nlHDxJC6Vej60jez20ju9f45F+lr5LbmzUm09/L175h4/8Ap7EKrWqqMjT7jdfTK2zf1U/a9mw/xU1nv/72q/YNs2j+fJpHdH47PqvQ9CaOMXeHyW11cR8Ayypt0lnvOldI9eLRTobZqRrbWfj9tGOC9HqfrXyPibmaQGs0yMHD952mpPHZQy7dktXcrPZznnP2hZg6MxVv1lqxryjlH3nxdVZYXTLoJQEBAQEBAQEBB5VEDXizhp4Ej5hNdDRocQ6HU8t7S1UZPGOom/RziPkra5rRyj5QrnHE9/zc/UdHJIZBG2plluL3dUzwyNA5Wf1bz5hvmp9dryj5Qj1enPzZYjgkwhJZiUzXXbZrntmba4tcOF77qPWRzrD3c7rPad2P0xaetpaljjl1YY3AnbYgH4r3XFPGJg0yR3S8We0CaBzxiFFLGGuDc8dntF+ZOm/iV7Gzxb9lnk5Zr+6GdTiNBiUMgD4y8Pc23clygjYHU6kcwvaXzYeHDyVZcGDP+6O3v5q1dSV9BGDnE9NdpLbWczy5emngFo38W08f02+rHGPNsc/p/VTu5x6+XhDoJqxlVTZc7X9a7ISRbIfEcCDqs01ybNkiZ7JhsrbDtmGdO2J8mkwaplM9NRTuD+pfI4mwH3TPsSLcO0LeQWvLpWtstf7xHnPb9HPwa3vTBaP45nX4R+n6+S5isktbMynDrRgufI0D3G6NBdzJ/gqtlnqcc5ufCPev2yOvy12aOHG3u5FTj5Zlip3h0x7IhY0WYBoAeO3D42UcOzzl1yZJ0r3zzWbRtcYNMWKutuURy96lUYC98/XYjUBvYJsSAxjb90u0FvL4lWW2qKfo2ePjzU02G2T9e1TrPdyj14ebCu6cUkTuopM0mVrbNp4x2yeNza/pdUdVkyTrefm3Vvjx13aR2d0PV/SHGpWOMNHHA1rR2qhxL7mwBLBYje+oXk0w14219yUWyW4RosRYFiZyunxbLe2ZkcbGix3s46hR36Rwq93bTxlQmw0NfIxlVPLK54DTJVOjYNCLu6qxd+6N+YXsZPCPkTTx821ougwsDNW1UltwyaSNhPH3i8/mTr+6I+RGLvmXQ0OCwxdzObftyyyf73FVTebJxWIbJRSEBAQEBAQEFapEx0iyN/E/M63+QWv+YL2NObydeTVT4JUy/eYhM0cW07IYR6FzXvH5lZF6xwrHxRmszzU5OgdI/wC+kqpufWVMpv8AAhe9faOGnyhHqazx1+ahV9AsHb2H0jyBqCJJzv450nacnf5QdTTua+p6D4aIX3hLQXDIHTSZstxfvP22XsZ8vqCcVGOJ9EMJaWmGpdG4ytJyVDbjva9q9hqpddlnjGvwR6qkcJ83icNlhe/6Li7rOcCMxjnaRbVpu6w+CReP7U/wmk/1s0eI9Ea18by6khlzOe4PpnCN+pa4Xj7pvbgy/ira5a6aa6e9C1La8PkrUXS+upmmGbO4AgdVP2XjLbuv7zb8jcaL22Gt41jyRrltWe119NURVg+lYe0NnaQ6alcQOsbx0Gl9e8NPVJyW3Yx5uHKe5T7PFbzmwdluccp/Pi3uDwxy1DKqODqwY3xuzWDg8EEAt4EZXtPoqbzNMc4rcpiY9y3HFcmWuevOJrPv1+saTChQySsbL1YDZpnPkc9xAbDTt0jcTsCQLgeN+CvitdIm/wC2vZp325/lmm15tMYv3X7Zn/1rwifjHD3uRxTpbBAwxUULXSk3fVSuBub3JbbV/wAh5peuTNOt+yOUQtw0x7PXSnbPOZ5tVDS1+IvE5hmqrBzftHdVFlO1naC3MNLTovbbuPhMQsjevx7XXU2CV8LSBV0lG2wAjgDA8j8Uj+0SB+Iqm2Sk8pn3rIpaOcR7nm3otSyiT6Vir3ueGixqY7dnnck8BxUestyr5JbledvN70nQvC3kAiJ17ZnGoLrjwDXCxKdfmj/h1OP1LZx+zbDHGW9OLOILSJZiRYaHv+Sh1+Tv8oS6qnc9qT2dUA1MT2P/AGo55hfx72hXvtOTnPlDzqKepXo+iXV6w11bHyHXCVv5ZmuC867XjWPl9kox6cJlsKalq2d6oZM23vx5HnxzxnL/AKFCZrPLT165pRFo5tky9td/O6gkyQEBAQEEOcBqUGsq8ZDbiOCeZ3JkZaPzy5W/NTimvGYhGbd0NVPX4xJ9xSQQjnUTF5/JELfNTiuKOMzPuj7oTOSeEKcuB43N95iUcQ5QQ/zOs75qUZMMcK/OUdzLP9vJVk9nEkn3+JVUnqbfBziApe0xHCsPJwTPG0sGeyOivczTk87xj+Re+2X7oPZq97P/ANpqD/Fn/Mz/ALF57Xfuh77PV5P9kVJwqJx/0z/IvfbLd0I+zV71R3siDTeGscx3Mx6/Frgpe2a8YeezacJVsR9n2KluT6XHUNGwmLyR+6Xhxb6EL2u0Y9ddNPc8nDfTjq5Ks6OYlQOExikjLDcSxkOA8czL2Hnor4y48nZr8FU0vXtdhgXtMgDS6pjeJCBnMQaWSOGjX2JGV1tD6a6BUZNntMRWJ7I4d8eHuTpkiJm3OePj4+/1ycvjePVGIO6imjkEZIJjYC58jts8mXgNAG91oA3tdaIrFf1Wn8e7/e9VEf1rH59cu5dwf2eYoSH5IoTzlLXEeIaA6x+BVd9px+9bXDd0LvZpWzf/AGcRc7wtI8W5DM8ADwsqvaaR+2qzqLTxs9IfY/TDvVMp/daxv6grydst3PPZa960z2S0I3mqD6xj+Ree2X7oS9mql3skoD/+k/xjP8i89rv4Hs1WDPZPTs1hq6iM+BYP9rQvfa7TxiD2aI4TKzH0LxGL7jF5h4Ss60f6nFR66k/upH0e9VeOFv8AVuKPHot5KOoH4hJC74tFvkozOGe+HsRljulsKfGqtulRQSt5uhfHO34Ah/yKhNK/1t/icWnnDb0tayQdnMPB7XMPweAVCY0SidVhePRAQEBAQEBAQEBAQEEEoACAQg5nEugOGzv6x8GVxNz1bnRh3O7Wm1/HdXV2jJWNIlVbDSZ10bjCMHp6VmSnibG3jlGpPNzjq4+JVdr2tOtpTrWK8F9RSQglAQEBAQEBAQEBAQEBAQEBAQaPoZiktVStmly5zJO3siwtHPJG3S+9mhBq6rpHUNbi5GT/AOEwuh7PH6IJu1r2u0fDRBTgxvEYTRunnpahtVJEzqo4nRTNEjcxe09Y4ODBq64GgJuEFuqrsRlrqinpqiCGOBkDvtYHSlxlDydRI2wGX5oNj0Uxx1RTPln6tpilmie+MnqnCFxaZGE6hht42sdUGu6EdJp6qRzKlrWdbG2rpgAQTSyPc1gdqbvaAwut/itQeYrsSnqqxkFTTQx00kbGiWB0hOaCOQkvErbC7zwQeVN0vqDTUlfI2NtO574qrLdwYOsdFHUsed4czQTe/ZkB4FBuqPFpaitkihy/R6ZuSV9rl9Q4BwjYb2AY0guOurwOBQZdJcVlp5KJkeW1RVCF9xfsGKV+nI3YNUHr0rxo0cAe1nWSySRwwsvlzyyuysBPAbknk0oNPiD8XpITUvmp6gRgvlgZC6LsDV4ikLycwFyMw1twugsYnj800kNNh+TrJofpDpZWucyKAkBpyAjM9xNg247ridkF7Coa+ORwqpoZocpIe2N0MjXAjsluZzXNIzG+hFuN9A02FV2J4hH9Kp5oaaB5Jga+F0z5GA2bJIS9uUOtcNGoBGqDb9E8ZkqGyx1DGsqKeUwytYSWE5Q5r2X1yOa4EA6jUcEG9QEBAQEBAQEBAQEBB8/6HY6aSnFPNR1+cTVGraWZzLSVMjmkOAtazgboMqzD5y3HgIn3mjIi7LvtD9BDOxp2u1ppxQaalw2FzaZuH4ZPTVbHU5dUGA0rGta5vX53G3WBzQ9uWxvdBv5ei0FXiNY6spusjMVK2Nzw4NPZkEga4WBPdvy0Qa2WkrHUH1SI5Wk1JozNkOUUQ+067PbKbw/ZeLyRugvYzglZTyU1ayeSpNM8MMTYY2k082WOUNETQXZew8DXuIMYuhtLWVWJOrabMJJoxG9wc0ln0WFpLHaXs4O1HEFBuOjMcstAaetiOdglppA5lmytjuxr2i1nMezKdNNSOCCfZxQmDDaVj4zG/qg6RrgWu6x3aeXA65iSb3QVun+drqGVsMsrYawSPEMbpXhnUTNvlaL2u4D1QVMfqZMRia6lpqhs1HPBVRsqYn0zZSwuDo2ueLXLC8eBLb23QZ4x0jnqqd9NS0NW2eZjo/t4XQxQ5hlc98ruw4NBJswuJtogiTDZMOngnhhkqIW0jKSURDNK0QnNFI1hPbbq8EDXUboKmDUccmJCWmpquKE09QJnTsnia6SV8ZblbMbk2EndFhdBZ6PYrLh1OyiqqSqe6AdXHJTwunjmjabRuBZfI7LYEPtqN7INp0Mw+dpqampZ1clXN1vVXBMcbY2xxNcRoX5W3NtNbcEHSoCAgICAgICAgICAgIIJQVqqpLC1rW5nPJsL2GguSSdgPXUhBTo8RebtyFzy+WzSWjK2N4abuHDUAWve/mgj61GYOs4NyPuzTN1jZWx5eV812jW2qD1lxQsuHxkO7FgCDmD3hmh01BIvfmN0FiqqzHH1jm69m4BFhcgXLuDRe5PIFBXdXE5bC5dHK8AOa5hyGMd62veFrePgg9YK0iASyC3YDyG68L6f0QTBWOMgjfGWktc8G4cLNLQRce92h/UoPGfFcpktG4tie1jiC3dzWOGUE62zi+3qgiXFwzMJG5XAsABc2x6y+U5jYAdl17/snfS4eX1uXmMRtabymN/aBAtC6QZXDQ7NN/MWQbfZBKAgICAgICAgICAgICAgglAAQeFVSh5aczmuaSQ5tr6ixFiCCDyPIckHgzCmtsWveHAvOa7S49YQ54NwQQSAdtLaIH1TFa3a7rhe+t3PDy6497ML35oJ+rQbl73vcSzU5RYMeHgANAAFxrz9BYLcrCRYOLTzFrj4ghBVp8MYw3uSbSAk2160tLyQAB7g2txQekdE0RdU4lzcuTW1y21t2gcOKDGGhyvEhe97g0sGbLazi0nRoAv2RqgPoGHrAb/aOD3a8WtY0W8LRt+aBPh7HOL7uDjksQRdpYXFpFx+NwN73BQH0WYNzSPLmPzh3ZvfKW2sG2tlcRtxQW0EIJQEBAQEBAQEBAQEBBBKAAglAQEBAQEBAQEBAQEBAQRsglAQEBAQEBAQEBBBKAAglAQEBAQEBAQEBAQEBAQEBBGyCUBAQEBAQEBBBKAAglAQEBAQEBAQEBAQEBAQEBAQEEbIJQEBAQEBBBKAAglAQEBAQEBAQEBAQEBAQEBAQEBAQY7IMkBAQEEEoACCUBAQEBAQEBAQEBAQEBAQEBAQEBAQEGOyDJAQQSgAIJQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBjsgyQQAglAQEBAQEFasroorda8Nvtfjq1v6uHxQV/ryl261u+U3uLHKHWPI2cDr/BAqMbgZa79w12gJs1zXODjptZpQRNjcDTbOToT2WudoHNZwHNwQT9eU2v2oNiWmwcdbtHAc3NtzuEAY1T279vDK+/ey2AtqbjbfigmHGIXNc7No17ozoSQ9riLWF+V/IgmyCJMdpm7yc/dce7a50G2o12N9EF8SDmNRf05+WoQawY9DqHXaQ57SDa/2cYkcdCdAHN9XAboPIdJIbA5X2tc6NNvvLNNnHU9W/blra6D0kx1gFyyTRkjyLMv9k7LIO9u08duRKDM4ywbteCJGxEEC4c9jHjjrpI3a5300QbNAQEBAQEBBjbkgyQEBAQEBAQVq2himAErA8Aki+tiQWn5EhB4PwSlOa8LDnN3abm73XPjeR/5kGb8JgcbujBNi3UnQEEEAX00JCCBg9OL2j3vxdx1IGuguAbDiAeCCfqmCzm9WLOvcXdxIJG+g0GmyCHYRAdcnzcLHNmuLHQ32I1CCfqmDWzLXJcbFze0Tcu0O558tNkEDCKfX7Ma358bEjfQdkabCyC41gFrDbRBT+p6bjE065u0MxvlDdzrbKALbWAHBBj9S0/GMHQjUuN75t7nU9p1idRmNkGbcKgFuxtzLjucxOp1JO53KCThcOcyZTmLs5Ic8dqzW30PJrRbk0ILiAgICAgICAg//9k="></a></li>
</ul>
<ul class="nav navbar-nav navbar-head"><a href="index1.php"><h1><font color="#7FB3D5"><b>Library Management System<h3>JIS COLLEGE OF ENGINEERING</h3><h5>NAAC 'A' Accredited Autonomous Institution</h5><h6>Affiliated by MAKAUT</h6><b><h1></a>
</ul>
    <?php if($_SESSION['login'])
{
?> 
            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
            </div>
</div>
            <?php }?>
      
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login'])
{
?>    
<section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                           
                          
   <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Account <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="my-profile.php">My Profile</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="change-password.php">Change Password</a></li>
                                </ul>
                            </li>
                            <li><a href="issued-books.php">Issued Books</a></li>
                            <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-books.php"> Books List</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <?php } else { ?>
        <section class="menu-section">
        
                        <ul id="menu-top" class="nav navbar-nav navbar-right">                        
                          
  <li><a href="adminlogin.php">Librarian Login</a></li>
                            <li><a href="signup.php">Student Signup</a></li>
                             <li><a href="index.php">Student Login</a></li>
                        </ul>
                   
        </div>
    </section>

    <?php } ?>
    </div>
</div>
</div>
</div>
<div class="container-fluid">
<div class= "row">
<div class="col-md-8">
<div class="navbar1">
<ul>
  <div class="topnav-container">
  <a class="active" href="index1.php"><i class="fa fa-home w3-xlarge"></i>Home</a>
  <a href="aboutus.php"><i class="fa fa-users"></i>About Us</a>
  <a href="ourteam.php"><i class="fa fa-child"></i>Our Team</a>
  <a href="gallery.php"><i class="fa fa-file-photo-o"></i>Gallery</a>
  <a href="contact.php"><i class="fa fa-phone"></i>Contact Us</a>
  </div>
  </ul>
  </div>
  </div>
  <div class="col-md-3">
  <form class="form-vertical">
<div class="form-group">
<input type="text" class="form-control" placeholder="Enter your search key">
</form>
</ul>
</div>
</div>
<div class="col-md-1"><button type="button"  class="btn btn-primary">Search</button>
</div>
</div>
</div>
</body>
</html>